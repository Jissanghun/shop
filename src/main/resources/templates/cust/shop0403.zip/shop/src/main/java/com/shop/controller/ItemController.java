package com.shop.controller;

import com.shop.dto.ItemDTO;
import com.shop.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/item")
public class ItemController {
    @Autowired
    ItemService itemService;

    String dir = "/item/";

    @RequestMapping("")
    public String cust(Model model){
        model.addAttribute("left",dir+"left");
        model.addAttribute("center",dir+"center");
        return "main";
    }
    @RequestMapping("/add")
    public String add(Model model){
        model.addAttribute("left",dir+"left");
        model.addAttribute("center",dir+"add");
        return "main";
    }
    @RequestMapping("/get")
    public String get(Model model){
        List<ItemDTO> list = null;

        try {
            list = itemService.get();
            model.addAttribute("ilist",list);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        model.addAttribute("left",dir+"left");
        model.addAttribute("center",dir+"get");
        return "main";
    }
}
